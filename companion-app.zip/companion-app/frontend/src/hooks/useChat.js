import { useCallback, useRef, useState } from "react";
import { sendMessage, fetchVoiceAudio } from "../api/client";

let idCounter = 0;
const nextId = () => `m_${++idCounter}_${Date.now()}`;

export function useChat() {
  const [messages, setMessages] = useState([]);
  const [isThinking, setIsThinking] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [voiceProvider, setVoiceProvider] = useState(null);
  const audioRef = useRef(null);

  const playAudio = useCallback((url, provider) => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
    }
    const audio = new Audio(url);
    audioRef.current = audio;
    setVoiceProvider(provider);
    setIsSpeaking(true);
    audio.onended = () => setIsSpeaking(false);
    audio.onerror = () => setIsSpeaking(false);
    audio.play().catch(() => setIsSpeaking(false));
  }, []);

  const send = useCallback(
    async (text) => {
      const trimmed = text.trim();
      if (!trimmed) return;

      const userMsg = { id: nextId(), role: "user", content: trimmed };
      setMessages((prev) => [...prev, userMsg]);
      setIsThinking(true);

      try {
        const history = [...messages, userMsg].map(({ role, content }) => ({
          role,
          content,
        }));
        const { reply } = await sendMessage(trimmed, history.slice(0, -1));

        const companionMsg = { id: nextId(), role: "companion", content: reply, audioState: "loading" };
        setMessages((prev) => [...prev, companionMsg]);
        setIsThinking(false);

        const audio = await fetchVoiceAudio(reply);
        setMessages((prev) =>
          prev.map((m) =>
            m.id === companionMsg.id
              ? { ...m, audioState: audio ? "ready" : "unavailable", audioUrl: audio?.url }
              : m
          )
        );

        if (audio) {
          playAudio(audio.url, audio.provider);
        }
      } catch (err) {
        console.error(err);
        setIsThinking(false);
        setMessages((prev) => [
          ...prev,
          {
            id: nextId(),
            role: "companion",
            content: "Hmm, I lost my train of thought for a second — say that again?",
            audioState: "unavailable",
            isError: true,
          },
        ]);
      }
    },
    [messages, playAudio]
  );

  const replay = useCallback(
    (message) => {
      if (message.audioUrl) {
        playAudio(message.audioUrl, voiceProvider);
      }
    },
    [playAudio, voiceProvider]
  );

  return { messages, isThinking, isSpeaking, voiceProvider, send, replay };
}
