const API_BASE = import.meta.env.VITE_API_BASE_URL || "http://localhost:8000";

/**
 * Sends the user's message + running history, returns the companion's text reply.
 * Throws on network/HTTP failure so callers can show a friendly inline error.
 */
export async function sendMessage(message, history) {
  const res = await fetch(`${API_BASE}/api/chat`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ message, history }),
  });

  if (!res.ok) {
    throw new Error(`Chat request failed (${res.status})`);
  }
  return res.json(); // { reply }
}

/**
 * Requests spoken audio for a line of text and returns a playable object URL.
 * Returns null (rather than throwing) if voice synthesis is unavailable, so
 * the UI can gracefully fall back to text-only.
 */
export async function fetchVoiceAudio(text) {
  try {
    const res = await fetch(`${API_BASE}/api/voice/stream`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text }),
    });

    if (!res.ok) {
      console.warn("Voice synthesis unavailable:", res.status);
      return null;
    }

    const provider = res.headers.get("X-Voice-Provider");
    const blob = await res.blob();
    return { url: URL.createObjectURL(blob), provider };
  } catch (err) {
    console.warn("Voice synthesis request failed:", err);
    return null;
  }
}
