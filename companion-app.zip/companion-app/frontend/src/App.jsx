import { useState } from "react";
import AgeGate from "./components/AgeGate";
import ChatWindow from "./components/ChatWindow";

export default function App() {
  const [confirmed, setConfirmed] = useState(false);

  return confirmed ? <ChatWindow /> : <AgeGate onConfirm={() => setConfirmed(true)} />;
}
