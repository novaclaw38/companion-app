import Waveform from "./Waveform";

export default function MessageBubble({ message, isCurrentlySpeaking, onReplay }) {
  const isUser = message.role === "user";

  return (
    <div className={`flex ${isUser ? "justify-end" : "justify-start"} animate-fade-up`}>
      <div
        className={[
          "max-w-[78%] rounded-2xl px-4 py-3 text-[15px] leading-relaxed",
          isUser
            ? "bg-amber text-deep rounded-br-sm"
            : "bg-panel border border-line text-cream rounded-bl-sm",
        ].join(" ")}
      >
        <p>{message.content}</p>

        {!isUser && !message.isError && (
          <div className="mt-2 flex items-center gap-2 h-4">
            {message.audioState === "loading" && (
              <span className="text-[11px] font-mono text-muted">finding his voice…</span>
            )}
            {message.audioState === "ready" && (
              <button
                onClick={() => onReplay(message)}
                className="flex items-center gap-1.5 text-muted hover:text-amber-soft transition"
                title="Play again"
              >
                <Waveform state={isCurrentlySpeaking ? "speaking" : "idle"} />
                <span className="text-[11px] font-mono">
                  {isCurrentlySpeaking ? "speaking" : "replay"}
                </span>
              </button>
            )}
            {message.audioState === "unavailable" && (
              <span className="text-[11px] font-mono text-muted/70">
                voice unavailable — text only
              </span>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
