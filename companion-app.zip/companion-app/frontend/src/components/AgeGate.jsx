import { useState } from "react";

export default function AgeGate({ onConfirm }) {
  const [checked, setChecked] = useState(false);

  return (
    <div className="min-h-screen flex items-center justify-center px-6 py-12">
      <div className="w-full max-w-md animate-fade-up">
        <div className="rounded-2xl border border-line bg-panel/80 backdrop-blur-sm p-8 shadow-glow">
          <p className="font-mono text-xs tracking-[0.2em] text-amber uppercase mb-3">
            Before you come in
          </p>
          <h1 className="font-display text-3xl text-cream mb-4 leading-tight">
            This is an 18+ space.
          </h1>
          <p className="text-muted text-sm leading-relaxed mb-6">
            Theo is a fictional AI companion built for playful, flirtatious
            conversation between consenting adults. It isn't a real person,
            and nothing it says is professional advice. You're always free to
            steer the conversation, slow it down, or end it whenever you'd
            like.
          </p>

          <label className="flex items-start gap-3 mb-7 cursor-pointer select-none group">
            <input
              type="checkbox"
              checked={checked}
              onChange={(e) => setChecked(e.target.checked)}
              className="mt-1 h-4 w-4 rounded border-line bg-panel-light accent-amber focus:ring-2 focus:ring-amber/50"
            />
            <span className="text-sm text-cream/90 group-hover:text-cream">
              I'm 18 or older and I'd like to continue.
            </span>
          </label>

          <button
            onClick={() => checked && onConfirm()}
            disabled={!checked}
            className="w-full rounded-xl bg-amber text-deep font-medium py-3 transition
                       disabled:opacity-30 disabled:cursor-not-allowed
                       enabled:hover:bg-amber-soft enabled:active:scale-[0.99]"
          >
            Continue
          </button>
        </div>
      </div>
    </div>
  );
}
