/**
 * A small voice waveform. Bars animate with staggered timing while the
 * companion is speaking; they sit low and still when idle, and pulse evenly
 * while a reply is being "thought through" before voice arrives.
 */
const BAR_COUNT = 5;
const DELAYS = ["0ms", "120ms", "60ms", "180ms", "30ms"];

export default function Waveform({ state = "idle" }) {
  // state: "idle" | "thinking" | "speaking"
  return (
    <div
      className="flex items-end gap-[3px] h-4 w-7"
      aria-hidden="true"
    >
      {Array.from({ length: BAR_COUNT }).map((_, i) => (
        <span
          key={i}
          className={[
            "w-[3px] rounded-full origin-bottom",
            state === "speaking" ? "bg-amber animate-wave" : "bg-muted/60",
            state === "thinking" ? "animate-wave" : "",
          ].join(" ")}
          style={{
            height: "100%",
            animationDelay: DELAYS[i],
            animationDuration: state === "thinking" ? "1.1s" : "0.7s",
            transform: state === "idle" ? "scaleY(0.25)" : undefined,
          }}
        />
      ))}
    </div>
  );
}
