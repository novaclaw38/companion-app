import { useEffect, useRef } from "react";
import MessageBubble from "./MessageBubble";
import ChatInput from "./ChatInput";
import Waveform from "./Waveform";
import { useChat } from "../hooks/useChat";

export default function ChatWindow() {
  const { messages, isThinking, isSpeaking, send, replay } = useChat();
  const scrollRef = useRef(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, isThinking]);

  const lastCompanionMsg = [...messages].reverse().find((m) => m.role === "companion");

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-8">
      <div className="w-full max-w-lg h-[85vh] flex flex-col rounded-2xl border border-line bg-panel/70 backdrop-blur-sm shadow-glow overflow-hidden">
        {/* Header */}
        <header className="flex items-center gap-3 px-5 py-4 border-b border-line">
          <div className="relative h-10 w-10 rounded-full bg-gradient-to-br from-amber to-rose flex items-center justify-center font-display text-deep text-lg">
            T
            <span className="absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full bg-emerald-400 border-2 border-panel" />
          </div>
          <div className="flex-1">
            <h1 className="font-display text-lg text-cream leading-none">Theo</h1>
            <p className="text-xs text-muted font-mono mt-1">
              {isSpeaking ? "speaking…" : isThinking ? "typing…" : "online"}
            </p>
          </div>
          <Waveform state={isSpeaking ? "speaking" : "idle"} />
        </header>

        {/* Messages */}
        <div ref={scrollRef} className="chat-scroll flex-1 overflow-y-auto px-5 py-5 space-y-4">
          {messages.length === 0 && (
            <div className="h-full flex flex-col items-center justify-center text-center px-6 animate-fade-up">
              <div className="h-16 w-16 rounded-full bg-gradient-to-br from-amber to-rose mb-4" />
              <p className="font-display text-xl text-cream mb-1">Theo's around tonight.</p>
              <p className="text-sm text-muted">Say hi and see where it goes.</p>
            </div>
          )}

          {messages.map((m) => (
            <MessageBubble
              key={m.id}
              message={m}
              isCurrentlySpeaking={isSpeaking && lastCompanionMsg?.id === m.id}
              onReplay={replay}
            />
          ))}

          {isThinking && (
            <div className="flex justify-start animate-fade-up">
              <div className="bg-panel border border-line rounded-2xl rounded-bl-sm px-4 py-3">
                <Waveform state="thinking" />
              </div>
            </div>
          )}
        </div>

        <ChatInput onSend={send} disabled={isThinking} />
      </div>
    </div>
  );
}
