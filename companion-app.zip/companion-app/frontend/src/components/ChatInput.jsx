import { useState } from "react";

export default function ChatInput({ onSend, disabled }) {
  const [value, setValue] = useState("");

  const submit = (e) => {
    e.preventDefault();
    if (!value.trim() || disabled) return;
    onSend(value);
    setValue("");
  };

  return (
    <form onSubmit={submit} className="flex items-center gap-2 p-4 border-t border-line bg-panel/60">
      <input
        autoFocus
        value={value}
        onChange={(e) => setValue(e.target.value)}
        placeholder="Say something…"
        disabled={disabled}
        className="flex-1 bg-panel-light text-cream placeholder:text-muted/70 rounded-xl px-4 py-3
                   text-[15px] outline-none border border-transparent focus:border-amber/40
                   transition disabled:opacity-50"
      />
      <button
        type="submit"
        disabled={disabled || !value.trim()}
        className="rounded-xl bg-amber text-deep px-5 py-3 font-medium transition
                   disabled:opacity-30 disabled:cursor-not-allowed
                   enabled:hover:bg-amber-soft enabled:active:scale-[0.98]"
      >
        Send
      </button>
    </form>
  );
}
