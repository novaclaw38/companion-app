"""
Centralized configuration. All secrets and tunables are read from environment
variables so nothing sensitive ever lives in source control.
"""
from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # --- App ---
    app_name: str = "Companion Chat API"
    environment: str = "development"
    cors_origins: str = "http://localhost:5173,http://127.0.0.1:5173"

    # --- LLM (text generation) ---
    # "template" requires no key and works out of the box on a free tier.
    # "openai" / "anthropic" use a real model for richer replies if a key is supplied.
    llm_provider: str = "template"
    openai_api_key: str | None = None
    openai_model: str = "gpt-4o-mini"
    anthropic_api_key: str | None = None
    anthropic_model: str = "claude-3-5-haiku-20241022"

    # --- Voice: ElevenLabs (primary) ---
    elevenlabs_api_key: str | None = None
    elevenlabs_voice_id: str = "TxGEqnHWrfWFTfGW9XjX"  # default ElevenLabs male voice ("Josh")
    elevenlabs_model_id: str = "eleven_turbo_v2_5"

    # --- Voice: Resemble AI (fallback) ---
    resemble_api_key: str | None = None
    resemble_project_uuid: str | None = None
    resemble_voice_uuid: str | None = None

    # --- Persona / safety ---
    # Hard ceiling on tone so the companion stays playful/suggestive rather than explicit,
    # regardless of what provider generates the text.
    max_reply_chars: int = 480


@lru_cache
def get_settings() -> Settings:
    return Settings()
