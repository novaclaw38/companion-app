from pydantic import BaseModel, Field


class ChatMessage(BaseModel):
    role: str  # "user" | "companion"
    content: str


class ChatRequest(BaseModel):
    message: str = Field(..., min_length=1, max_length=1000)
    history: list[ChatMessage] = Field(default_factory=list)


class ChatResponse(BaseModel):
    reply: str
    audio_url: str | None = None
    voice_provider: str | None = None  # "elevenlabs" | "resemble" | None


class VoiceRequest(BaseModel):
    text: str = Field(..., min_length=1, max_length=600)


class HealthResponse(BaseModel):
    status: str
    elevenlabs_configured: bool
    resemble_configured: bool
    llm_provider: str
