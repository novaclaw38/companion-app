import logging

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse

from app.config import Settings, get_settings
from app.models.schemas import HealthResponse, VoiceRequest
from app.services.tts_service import TTSService, VoiceSynthesisError

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/voice", tags=["voice"])


def get_tts_service(settings: Settings = Depends(get_settings)) -> TTSService:
    return TTSService(settings)


@router.post("/stream")
async def stream_voice(
    request: VoiceRequest,
    tts_service: TTSService = Depends(get_tts_service),
):
    """
    Streams synthesized speech for the given text as audio/mpeg.
    Falls back from ElevenLabs to Resemble AI internally; the client doesn't
    need to know which provider ultimately served the audio (it's exposed in
    the X-Voice-Provider header for debugging/telemetry only).
    """
    try:
        # Peek the first chunk so we know which provider succeeded before
        # committing to the response headers, while still streaming the rest.
        agen = tts_service.synthesize_stream(request.text)
        first_chunk, provider = await agen.__anext__()
    except StopAsyncIteration:
        raise HTTPException(status_code=502, detail="Voice provider returned no audio.")
    except VoiceSynthesisError as exc:
        logger.error("Voice synthesis unavailable: %s", exc)
        raise HTTPException(
            status_code=503,
            detail="Voice synthesis is temporarily unavailable. Showing text only.",
        )

    async def audio_iterator():
        yield first_chunk
        async for chunk, _ in agen:
            yield chunk

    return StreamingResponse(
        audio_iterator(),
        media_type="audio/mpeg",
        headers={"X-Voice-Provider": provider, "Cache-Control": "no-store"},
    )


@router.get("/health", response_model=HealthResponse)
async def voice_health(settings: Settings = Depends(get_settings)) -> HealthResponse:
    return HealthResponse(
        status="ok",
        elevenlabs_configured=bool(settings.elevenlabs_api_key),
        resemble_configured=bool(
            settings.resemble_api_key
            and settings.resemble_project_uuid
            and settings.resemble_voice_uuid
        ),
        llm_provider=settings.llm_provider,
    )
