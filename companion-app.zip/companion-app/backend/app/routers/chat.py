import logging

from fastapi import APIRouter, Depends

from app.config import Settings, get_settings
from app.models.schemas import ChatRequest, ChatResponse
from app.services.llm_service import LLMService

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/chat", tags=["chat"])


def get_llm_service(settings: Settings = Depends(get_settings)) -> LLMService:
    return LLMService(settings)


@router.post("", response_model=ChatResponse)
async def chat(
    request: ChatRequest,
    llm_service: LLMService = Depends(get_llm_service),
) -> ChatResponse:
    """
    Returns the companion's text reply only. The frontend immediately renders
    this, then separately requests /api/voice/stream for the spoken audio —
    this keeps the conversation feeling instant instead of waiting on TTS
    before showing anything.
    """
    reply = await llm_service.generate_reply(request.message, request.history)
    return ChatResponse(reply=reply)
