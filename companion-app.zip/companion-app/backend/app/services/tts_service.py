"""
Text-to-speech orchestration.

Primary provider: ElevenLabs (streaming, low latency).
Fallback provider: Resemble AI, used transparently if ElevenLabs errors out,
times out, or is unauthorized/rate-limited (common on free tiers).

Both providers are wrapped behind the same interface so routers don't need
to know which one actually produced the audio.
"""
import logging
from collections.abc import AsyncIterator

import httpx

from app.config import Settings

logger = logging.getLogger(__name__)

ELEVENLABS_BASE = "https://api.elevenlabs.io/v1"
RESEMBLE_BASE = "https://app.resemble.ai/api/v2"

# Tuned for a warm, natural, slightly playful male delivery rather than a flat
# "read the text" cadence. Lower stability = more expressive/varied inflection.
ELEVENLABS_VOICE_SETTINGS = {
    "stability": 0.42,
    "similarity_boost": 0.8,
    "style": 0.35,
    "use_speaker_boost": True,
}


class VoiceSynthesisError(Exception):
    """Raised when every configured provider fails."""


class TTSService:
    def __init__(self, settings: Settings):
        self.settings = settings

    # ---------- public API ----------

    async def synthesize_stream(self, text: str) -> AsyncIterator[tuple[bytes, str]]:
        """
        Yields (chunk_bytes, provider_name) tuples. Tries ElevenLabs streaming
        first; if it fails before any audio is produced, transparently falls
        back to a single Resemble AI clip (yielded as one chunk).
        """
        if self.settings.elevenlabs_api_key:
            try:
                async for chunk in self._stream_elevenlabs(text):
                    yield chunk, "elevenlabs"
                return
            except Exception as exc:
                logger.warning("ElevenLabs streaming failed, falling back to Resemble: %s", exc)

        if self.settings.resemble_api_key:
            try:
                audio = await self._synthesize_resemble(text)
                yield audio, "resemble"
                return
            except Exception as exc:
                logger.warning("Resemble AI synthesis failed: %s", exc)

        raise VoiceSynthesisError("All configured voice providers failed or are unconfigured.")

    async def synthesize(self, text: str) -> tuple[bytes, str]:
        """Non-streaming convenience wrapper — buffers the full stream."""
        chunks: list[bytes] = []
        provider_used = "none"
        async for chunk, provider in self.synthesize_stream(text):
            chunks.append(chunk)
            provider_used = provider
        return b"".join(chunks), provider_used

    # ---------- ElevenLabs ----------

    async def _stream_elevenlabs(self, text: str) -> AsyncIterator[bytes]:
        url = (
            f"{ELEVENLABS_BASE}/text-to-speech/"
            f"{self.settings.elevenlabs_voice_id}/stream"
        )
        headers = {
            "xi-api-key": self.settings.elevenlabs_api_key,
            "Content-Type": "application/json",
            "Accept": "audio/mpeg",
        }
        payload = {
            "text": text,
            "model_id": self.settings.elevenlabs_model_id,
            "voice_settings": ELEVENLABS_VOICE_SETTINGS,
        }

        async with httpx.AsyncClient(timeout=20.0) as client:
            async with client.stream("POST", url, headers=headers, json=payload) as response:
                if response.status_code != 200:
                    body = await response.aread()
                    raise RuntimeError(
                        f"ElevenLabs returned {response.status_code}: {body[:200]!r}"
                    )
                async for chunk in response.aiter_bytes():
                    if chunk:
                        yield chunk

    # ---------- Resemble AI ----------

    async def _synthesize_resemble(self, text: str) -> bytes:
        if not self.settings.resemble_project_uuid or not self.settings.resemble_voice_uuid:
            raise RuntimeError("Resemble project/voice UUID not configured")

        url = f"{RESEMBLE_BASE}/projects/{self.settings.resemble_project_uuid}/clips"
        headers = {
            "Authorization": f"Token token={self.settings.resemble_api_key}",
            "Content-Type": "application/json",
        }
        payload = {
            "data": {
                "body": text,
                "voice_uuid": self.settings.resemble_voice_uuid,
                "is_public": False,
                "sample_rate": 22050,
                "output_format": "mp3",
            }
        }

        async with httpx.AsyncClient(timeout=30.0) as client:
            create_resp = await client.post(url, headers=headers, json=payload)
            if create_resp.status_code not in (200, 201):
                raise RuntimeError(
                    f"Resemble create-clip returned {create_resp.status_code}: "
                    f"{create_resp.text[:200]}"
                )
            data = create_resp.json()
            audio_src = data.get("item", {}).get("audio_src")
            if not audio_src:
                raise RuntimeError("Resemble response had no audio_src to download")

            audio_resp = await client.get(audio_src)
            audio_resp.raise_for_status()
            return audio_resp.content
