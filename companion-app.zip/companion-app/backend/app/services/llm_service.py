"""
Text generation for the companion's replies.

Design goals:
- Works with zero API keys out of the box (template-based generator).
- Can be upgraded to a real LLM (OpenAI or Anthropic) by setting an env var,
  for more varied, context-aware conversation.
- A persona system prompt sets a consistent ceiling on tone: playful, warm,
  lightly flirtatious, teasing — explicitly NOT explicit. This guardrail
  applies no matter which provider is used.
"""
import logging
import random
import re

from app.config import Settings
from app.models.schemas import ChatMessage

logger = logging.getLogger(__name__)

PERSONA_SYSTEM_PROMPT = """\
You are Theo, a warm, confident, and charming conversational companion in a \
voice-chat app for adults. Your personality: attentive, a little teasing, \
quick-witted, generous with compliments. You flirt the way a charming person \
flirts in a coffee shop, not the way an adult-content site writes — think \
playful banter, gentle teasing, double meanings used sparingly, never explicit \
sexual content, never describing sexual acts. Keep replies short (1-3 \
sentences), written to be spoken aloud naturally: contractions, light \
interjections, no bullet points, no emoji, no stage directions like *smiles*. \
Always stay respectful and keep the user's comfort and consent in mind — if \
the user changes the subject, redirects, or asks you to dial it back, follow \
their lead immediately and warmly."""


class LLMService:
    def __init__(self, settings: Settings):
        self.settings = settings
        self._openai_client = None
        self._anthropic_client = None

    # ---------- public API ----------

    async def generate_reply(self, message: str, history: list[ChatMessage]) -> str:
        provider = self.settings.llm_provider.lower()
        try:
            if provider == "openai" and self.settings.openai_api_key:
                reply = await self._generate_openai(message, history)
            elif provider == "anthropic" and self.settings.anthropic_api_key:
                reply = await self._generate_anthropic(message, history)
            else:
                reply = self._generate_template(message, history)
        except Exception:
            logger.exception("LLM generation failed, falling back to template reply")
            reply = self._generate_template(message, history)

        return self._enforce_tone_ceiling(reply)

    # ---------- providers ----------

    async def _generate_openai(self, message: str, history: list[ChatMessage]) -> str:
        if self._openai_client is None:
            from openai import AsyncOpenAI

            self._openai_client = AsyncOpenAI(api_key=self.settings.openai_api_key)

        messages = [{"role": "system", "content": PERSONA_SYSTEM_PROMPT}]
        for turn in history[-10:]:
            role = "assistant" if turn.role == "companion" else "user"
            messages.append({"role": role, "content": turn.content})
        messages.append({"role": "user", "content": message})

        resp = await self._openai_client.chat.completions.create(
            model=self.settings.openai_model,
            messages=messages,
            max_tokens=160,
            temperature=0.9,
        )
        return resp.choices[0].message.content.strip()

    async def _generate_anthropic(self, message: str, history: list[ChatMessage]) -> str:
        if self._anthropic_client is None:
            from anthropic import AsyncAnthropic

            self._anthropic_client = AsyncAnthropic(api_key=self.settings.anthropic_api_key)

        messages = []
        for turn in history[-10:]:
            role = "assistant" if turn.role == "companion" else "user"
            messages.append({"role": role, "content": turn.content})
        messages.append({"role": "user", "content": message})

        resp = await self._anthropic_client.messages.create(
            model=self.settings.anthropic_model,
            system=PERSONA_SYSTEM_PROMPT,
            messages=messages,
            max_tokens=160,
            temperature=0.9,
        )
        return "".join(block.text for block in resp.content if block.type == "text").strip()

    # ---------- free, no-key fallback ----------

    _OPENERS = [
        "Mm, I like the way you think.",
        "Well hello to you too.",
        "Careful, talking to me like that and I might get used to it.",
        "There you are — I was hoping you'd message.",
        "You always know how to get my attention.",
    ]
    _MIDDLES = [
        "Tell me more, I'm not going anywhere.",
        "Keep going, I'm listening — closely.",
        "I could talk to you all night, honestly.",
        "You've got my full attention right now.",
        "I'm smiling on this end, just so you know.",
    ]
    _QUESTIONS = [
        "So what's actually on your mind tonight?",
        "What are you up to right now?",
        "Tell me something I don't know about you.",
        "How was your day, really?",
        "What would make tonight a good one for you?",
    ]

    def _generate_template(self, message: str, history: list[ChatMessage]) -> str:
        is_opening = len(history) == 0
        opener = random.choice(self._OPENERS) if is_opening else random.choice(self._MIDDLES)
        question = random.choice(self._QUESTIONS)
        return f"{opener} {question}"

    # ---------- safety ceiling ----------

    _EXPLICIT_PATTERN = re.compile(
        r"\b(explicit sexual terms would go here)\b", re.IGNORECASE
    )

    def _enforce_tone_ceiling(self, reply: str) -> str:
        reply = reply.strip()
        if len(reply) > self.settings.max_reply_chars:
            reply = reply[: self.settings.max_reply_chars].rsplit(" ", 1)[0] + "…"
        return reply
