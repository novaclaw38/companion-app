import logging

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import get_settings
from app.routers import chat, voice

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
)
logger = logging.getLogger(__name__)

settings = get_settings()

app = FastAPI(
    title=settings.app_name,
    description="Backend for a voice-enabled chat companion app.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[origin.strip() for origin in settings.cors_origins.split(",")],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["X-Voice-Provider"],
)

app.include_router(chat.router)
app.include_router(voice.router)


@app.get("/api/health")
async def health():
    return {"status": "ok", "service": settings.app_name, "environment": settings.environment}


@app.on_event("startup")
async def startup_event():
    logger.info("Starting %s (env=%s)", settings.app_name, settings.environment)
    logger.info("LLM provider: %s", settings.llm_provider)
    logger.info("ElevenLabs configured: %s", bool(settings.elevenlabs_api_key))
    logger.info(
        "Resemble AI configured: %s",
        bool(settings.resemble_api_key and settings.resemble_project_uuid),
    )
