# Theo — Voice Chat Companion

A full-stack chat companion app: React frontend, FastAPI backend, with
ElevenLabs as the primary text-to-speech provider and Resemble AI as an
automatic fallback if ElevenLabs is unavailable, unauthorized, or rate-limited.

```
companion-app/
├── backend/        FastAPI app (chat + voice synthesis)
└── frontend/       React 18 + Vite + Tailwind chat UI
```

## How it fits together

1. User sends a message → `POST /api/chat` returns the companion's text reply
   immediately (so the UI never feels stuck waiting on audio).
2. The frontend separately requests `POST /api/voice/stream` with that reply
   text, which streams back `audio/mpeg` from ElevenLabs. If ElevenLabs fails
   for any reason, the backend transparently retries with Resemble AI before
   giving up — the frontend only ever sees one response, with an
   `X-Voice-Provider` header noting which provider produced it.
3. If both voice providers fail, the chat continues with text only and the
   bubble shows "voice unavailable — text only" instead of breaking.

## Backend setup

```bash
cd backend
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
# edit .env and add your ElevenLabs / Resemble keys (see below)
uvicorn app.main:app --reload --port 8000
```

### Getting free-tier keys

- **ElevenLabs**: sign up at elevenlabs.io → Profile → API Keys. The free
  tier includes ~10k characters/month, enough for local testing.
- **Resemble AI**: sign up at resemble.ai → create a project and a voice,
  then grab the project UUID, voice UUID, and API token from your dashboard.

Leaving `ELEVENLABS_API_KEY` / `RESEMBLE_API_KEY` blank is fine — the app
runs with text-only replies until you add a voice key, and `LLM_PROVIDER`
defaults to a free, no-key template generator for the text itself. Set
`LLM_PROVIDER=openai` or `anthropic` with the matching API key for richer,
context-aware conversation.

## Frontend setup

```bash
cd frontend
npm install
cp .env.example .env   # defaults to http://localhost:8000, change if needed
npm run dev
```

Visit `http://localhost:5173`.

## Notes on the persona

The companion's tone is set by a system prompt in
`backend/app/services/llm_service.py` (`PERSONA_SYSTEM_PROMPT`): playful,
warm, lightly flirtatious banter — explicitly steered away from explicit
content regardless of which LLM provider is plugged in. The frontend also
gates entry behind a brief 18+ consent screen. If you extend the persona,
keep that ceiling in the system prompt rather than removing it.

## Error handling & fallback summary

| Failure                          | Behavior                                      |
|-----------------------------------|------------------------------------------------|
| ElevenLabs request fails/errors  | Backend retries with Resemble AI automatically |
| Resemble AI also fails            | `/api/voice/stream` returns 503; UI shows text only |
| LLM provider (OpenAI/Anthropic) fails | Backend falls back to the built-in template generator |
| Network error on the frontend     | Inline error bubble, chat stays usable          |
